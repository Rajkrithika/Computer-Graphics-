"use strict";

var gl;
var points;
var colorLoc;
var NumPoints = 5000;
var step = 500;
var speed = 100; // add this line to define speed
var colorPicker;

var colorTrans = true;


window.onload = function init() {
	var canvas = document.getElementById( "gl-canvas" );

	var slider = document.getElementById( "num-points-slider" );
	var output = document.getElementById( "num-points-output" );
	// Get the color picker element
	var colorPicker = document.getElementById( "color-picker" );
	var status = document.getElementById( "status" );




	slider.oninput = function () {
		output.innerHTML = this.value;
		NumPoints = this.value;
		updatePoints();
	}



	gl = WebGLUtils.setupWebGL( canvas );
	if ( !gl ) {
		alert( "WebGL isn't available" );
	}

	//
	//  Initialize our data for the Sierpinski Gasket
	//

	// Set the initial color value
	var color = vec4( 1.0, 0.0, 0.0, 1.0 ); // Red


	var toggleButton = document.getElementById( "toggle-button" );
	toggleButton.addEventListener( "click", toggleBetweenLinesAndDots );

	var speedSlider = document.getElementById( "speed-slider" );
	speed = speedSlider.value;
	speedSlider.oninput = function () {
		speed = this.value;
	}

	var viewportSizeSlider = document.getElementById( "viewport-size-slider" );
	var viewportSizeOutput = document.getElementById( "viewport-size-output" );

	viewportSizeSlider.addEventListener( "input", function () {
		var size = parseFloat( viewportSizeSlider.value );
		gl.viewport( 0, 0, size * canvas.width, size * canvas.height );
		viewportSizeOutput.innerHTML = size.toFixed( 2 );
		render(); // Add this line to call render() after updating the viewport size
	} );




	// First, initialize the corners of our gasket with three points.


	var vertices = [
    vec2( -1, -1 ),
    vec2( 0, 1 ),
    vec2( 1, -1 )
  ];

	// Specify a starting point p for our iterations
	// p must lie inside any set of three vertices

	var u = add( vertices[ 0 ], vertices[ 1 ] );
	var v = add( vertices[ 0 ], vertices[ 2 ] );
	var p = scale( 0.25, add( u, v ) );

	// And, add our initial point into our array of points

	points = [ p ];

	// Compute new points
	// Each new point is located midway between
	// last point and a randomly chosen vertex

	for ( var i = 0; points.length < NumPoints; ++i ) {
		var j = Math.floor( Math.random() * 3 );
		p = add( points[ i ], vertices[ j ] );
		p = scale( 0.5, p );
		points.push( p );
	}



	//
	//  Configure WebGL
	//
	gl.viewport( 0, 0, canvas.width, canvas.height );
	gl.clearColor( 1.0, 1.0, 1.0, 1.0 );

	//  Load shaders and initialize attribute buffers

	var program = initShaders( gl, "vertex-shader", "fragment-shader" );
	gl.useProgram( program );

	// Load the data into the GPU

	var bufferId = gl.createBuffer();
	gl.bindBuffer( gl.ARRAY_BUFFER, bufferId );
	gl.bufferData( gl.ARRAY_BUFFER, flatten( points ), gl.STATIC_DRAW );

	// Associate out shader variables with our data buffer

	var vPosition = gl.getAttribLocation( program, "vPosition" );
	gl.vertexAttribPointer( vPosition, 2, gl.FLOAT, false, 0, 0 );
	gl.enableVertexAttribArray( vPosition );

	colorLoc = gl.getUniformLocation( program, "color" );
	// Pass the color uniform to the fragment shader

	// Listen for changes to the color picker value
	colorPicker.addEventListener( "input", function () {
		// Convert the hex color code to a vec4 color value
		var hexColor = colorPicker.value.replace( "#", "" );
		var r = parseInt( hexColor.substring( 0, 2 ), 16 ) / 255;
		var g = parseInt( hexColor.substring( 2, 4 ), 16 ) / 255;
		var b = parseInt( hexColor.substring( 4, 6 ), 16 ) / 255;
		color = vec4( r, g, b, 1.0 );
	} );

	gl.uniform4fv( gl.getUniformLocation( program, "color" ), color );

	function animate() {
		setTimeout( function () {
			requestAnimFrame( animate );
			render( color );
		}, 1000 / speed );
	}
	animate();



	function updatePoints() {
		var u = add( vertices[ 0 ], vertices[ 1 ] );
		var v = add( vertices[ 0 ], vertices[ 2 ] );
		var p = scale( 0.25, add( u, v ) );
		points = [ p ];

		for ( var i = 0; points.length < NumPoints; ++i ) {
			var j = Math.floor( Math.random() * 3 );
			p = add( points[ i ], vertices[ j ] );
			p = scale( 0.5, p );
			points.push( p );
		}

		gl.bindBuffer( gl.ARRAY_BUFFER, bufferId );
		gl.bufferData( gl.ARRAY_BUFFER, flatten( points ), gl.STATIC_DRAW );
	}

};


var size = 1;
var direction = -0.01;
var currentNumPoints = 500;


function render( color ) {
	var canvas = document.getElementById( "gl-canvas" );

	const toggleDynamicColor = document.getElementById( 'toggle-dynamic-color' );

	toggleDynamicColor.addEventListener( 'click', function () {
		colorTrans = !colorTrans;

		console.log( colorTrans, 'asd' );
	} );


	size += direction;
	if ( size < 0.5 || size > 1 ) {
		direction *= -1;
	}

	gl.viewport( 0, 0, size * canvas.width, size * canvas.height );
	console.log( colorTrans );
	if ( colorTrans ) {
		gl.uniform4fv( colorLoc, vec4( color[ 0 ], color[ 1 ], color[ 2 ], color[ 3 ] ) )

	} else {
		gl.uniform4fv( colorLoc, [ Math.random(), Math.random(), Math.random(), 1.0 ] );

	}
	setStatus( "changed the color of the canvas to color..." )
	gl.clear( gl.COLOR_BUFFER_BIT );

	currentNumPoints += step;
	if ( currentNumPoints > NumPoints ) {
		currentNumPoints = 0;

		var delay = 1000 / ( speed * 10 ); // calculate delay based on speed
		setTimeout( function () {
			requestAnimFrame( render );
		}, delay );
	}

	if ( isDots ) {
		setStatus( "Rendering triangle by points..." )
		gl.drawArrays( gl.POINTS, 0, currentNumPoints );
	} else {
		setStatus( "Rendering triangle by line..." )
		gl.drawArrays( gl.LINE_STRIP, 0, currentNumPoints );
	}

	// Clear the status message
	// setStatus( "" );

}

var isDots = true;

function toggleBetweenLinesAndDots() {
	isDots = !isDots;
}

function setStatus( message ) {

	var status = document.getElementById( "status" );
	status.innerHTML = "Status : " + message;
}