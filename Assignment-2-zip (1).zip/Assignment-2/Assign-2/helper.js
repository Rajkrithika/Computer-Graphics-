function updatePoints() {
  var vertices = [    vec2(-1, -1),    vec2(0, 1),    vec2(1, -1)  ];

  var u = add(vertices[0], vertices[1]);
  var v = add(vertices[0], vertices[2]);
  var p = scale(0.25, add(u, v));

  points = [p];

  for (var i = 0; points.length < NumPoints; ++i) {
    var j = Math.floor(Math.random() * 3);
    p = add(points[i], vertices[j]);
    p = scale(0.5, p);
    points.push(p);
  }

  currentNumPoints = 0;
  step = Math.floor(NumPoints / 50);
  if (step < 1) {
    step = 1;
  }

  gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
  gl.bufferData(gl.ARRAY_BUFFER, flatten(points), gl.STATIC_DRAW);
};
